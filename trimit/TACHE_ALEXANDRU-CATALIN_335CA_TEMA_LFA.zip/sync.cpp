#include <bits/stdc++.h>
#include <iostream>
#include <string>
using namespace std;

#define SIZE 1000

int *V;
int k;
 
class Graph {
public:
    map<int, bool> visited;
    map<int, list<int> > adj;
 
    void addEdge(int v, int w);

    void DFS(int v);
};

//adaugare legatura intre 2 noduri 
void Graph::addEdge(int v, int w)
{
    adj[v].push_back(w); 
}
 
//algoritm DFS
void Graph::DFS(int v)
{
    visited[v] = true;
    //cout << v << " ";
    V[k] = v;
    k++;

    list<int>::iterator i;
    for (i = adj[v].begin(); i != adj[v].end(); ++i)
        if (!visited[*i])
            DFS(*i);
}

//MergeSort
void merge(int arr[], int l, int m, int r)
{
    int i, j, k;
    int n1 = m - l + 1;
    int n2 = r - m;
  
    int L[n1], R[n2];
  
    for (i = 0; i < n1; i++) {
        L[i] = arr[l + i];
    }
    for (j = 0; j < n2; j++) {
        R[j] = arr[m + 1 + j];
    }
  
    i = 0; 
    j = 0; 
    k = l; 

    while (i < n1 && j < n2) {
        if (L[i] <= R[j]) {
            arr[k] = L[i];
            i++;
        }
        else {
            arr[k] = R[j];
            j++;
        }
        k++;
    }

    while (i < n1) {
        arr[k] = L[i];
        i++;
        k++;
    }
  
    while (j < n2) {
        arr[k] = R[j];
        j++;
        k++;
    }
}
  
void mergeSort(int arr[], int l, int r)
{
    if (l < r) {
        int m = l + (r - l) / 2;
        mergeSort(arr, l, m);
        mergeSort(arr, m + 1, r);
        merge(arr, l, m, r);
    }
}

int main(int argc, char * argv[])
{   
    //citire date 
    int n, m, s, f;

    cin >> n;
    cin >> m;
    cin >> s;
    cin >> f;

    int *vector_s = (int*) malloc(sizeof(int) * s);
    int *vector_f = (int*) malloc(sizeof(int) * f);


    Graph g;
    //int ma[SIZE][SIZE];

    int **ma = (int **)malloc(n * sizeof(int*));
    for(int i = 0; i < n; i++) {
         ma[i] = (int *)malloc(m * sizeof(int));
    }

    for(int i = 0; i < n; i++) {
        for(int j = 0; j < m; j++) {
            cin >> ma[i][j];
            g.addEdge(i, ma[i][j]);  //completare legaturi din graf
        }
    }

    for(int i = 0; i < s; i++) {
        cin >> vector_s[i];
    }


    for(int i = 0; i < f; i++) {
        cin >> vector_f[i];
    }


    V = (int*) malloc(sizeof(int) * n * m);

    int ok = 0;
   
    //verificare nume problema
    if(strcmp("accessible", argv[1]) == 0) {

    k = 0;
    for(int i = 0; i < s; i++) {
        
        g.DFS(vector_s[i]);
        
    }

    mergeSort(V, 0, k - 1);

    for(int i = 0; i < k; i++) {
        if(V[i] != V[i-1] || i == 0) {
            cout << V[i];
            cout << endl;
        }
    }
    
    } else if(strcmp("productive", argv[1]) == 0) {
    
    k = 0;
    int index = 0;
    int *v_final = (int*) malloc(sizeof(int) * n * m);
    for(int i = 0; i < n; i++) {
        k = 0;

         //initializez mereu cu false toate durile vizitate
        for(int a = 0; a < sizeof(g.visited); a++) {
            g.visited[a] = false;
        }
        
        //parcurg dfs
        g.DFS(i);
        
        ok = 0;
        //verific daca prin nodul curent pot trece prin toate starile din f
        for(int j = 0; j < f; j++) {
            for(int l = 0; l < k; l++) {
                if(V[l] == vector_f[j]) {
                    ok += 1;
                    break;
                }
            }
            if(ok != 0) {
                break;
            }
        }
        if(ok != 0) {
            v_final[index] = i;
            index++;
        }
        
    }

    mergeSort(v_final, 0, index - 1);

    for(int i = 0; i < index; i++) {
        if(v_final[i] != v_final[i-1] || i == 0) {
            cout << v_final[i];
            cout << endl;
        }
    }
    
    } else if(strcmp("useful", argv[1]) == 0) {

        k = 0;
    for(int i = 0; i < s; i++) {
        
        g.DFS(vector_s[i]);
        
    }

    mergeSort(V, 0, k - 1);

    int*vector_acc = (int*) malloc(sizeof(int) * k);
    int p = 0;

    for(int i = 0; i < k; i++) {
        if(V[i] != V[i-1] || i == 0) {
            vector_acc[p] =  V[i];
            p++;
        }
    }

    k = 0;
    int index = 0;
    int *v_final = (int*) malloc(sizeof(int) * n * m);
    for(int a = 0; a < sizeof(g.visited); a++) {
            g.visited[a] = false;
        }
    for(int i = 0; i < n; i++) {
        k = 0;
        
        //parcurg dfs
        g.DFS(i);
        //initializez mereu cu false toate durile vizitate
        for(int a = 0; a < sizeof(g.visited); a++) {
            g.visited[a] = false;
        }

        ok = 0;
        //verific daca prin nodul curent pot trece prin toate starile din f
        for(int j = 0; j < f; j++) {
            for(int l = 0; l < k; l++) {
                if(V[l] == vector_f[j]) {
                    ok += 1;
                    break;
                }
            }
            if(ok != 0) {
                break;
            }
        }
        if(ok != 0) {
            v_final[index] = i;
            index++;
        }
        
    }

    mergeSort(v_final, 0, index - 1);

    int* vec_prod = (int*) malloc(sizeof(int) * index);
    int t = 0;
    for(int i = 0; i < index; i++) {
        if(v_final[i] != v_final[i-1] || i == 0) {
            vec_prod[t] =  v_final[i];
            t++;
        }
         
    }

    for(int i = 0; i < p; i++) {
        for(int j = 0; j < t; j++) {
            if(vec_prod[j] == vector_acc[i]) {
                cout<<vector_acc[i]<<endl;
                break;
            }
        }
    }
    }
    free(V);
    return 0;
}